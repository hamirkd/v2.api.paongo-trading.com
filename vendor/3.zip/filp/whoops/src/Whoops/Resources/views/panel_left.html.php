<?php 
$tpl->render($header_outer);
$tpl->render($frames_description);
$tpl->render($frames_container);
